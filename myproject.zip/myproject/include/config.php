<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['ssmonline'] = array ('1'=>'ssmonline<|<admin','ssmonline>|>aWNlbGY=');






$data['Pabna'] = array ('1'=>'Pabna!58.84.32.102','Pabna@|@api','Pabna#|#amZqaA==','Pabna%WCL-WiFi Voucher','Pabna^weblink.net','Pabna&BDT','Pabna*10','Pabna(1','Pabna)','Pabna=10','Pabna@!@enable');