<html>
<head>
<title>Thank you for registering with us</title>
<link href="./css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="response-text">
        Thank you for registering with us!
    </div>
</body>
</html>