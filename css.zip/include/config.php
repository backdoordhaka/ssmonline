<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['ssmonline'] = array ('1'=>'ssmonline<|<admin','ssmonline>|>mZWfoZ9yaWNlbGY=');



































